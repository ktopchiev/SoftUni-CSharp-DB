﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarDealer.DTO.Import
{
    public class Supplier
    {
        public string Name { get; set; }

        public bool IsImporter { get; set; }
    }
}
